
BLACKJACK

To Play Game:
Must have Python 3
'pip install pydealer'
'python blackjack.py'

Rules for Blackjack: https://www.bicyclecards.com/how-to-play/blackjack/
Game Specifics:
	- User will start with 100 chips
	- Blackjack pays out 3:2
	- Double Down and Split bets can be less than or equal to original bet
	- Only one card will be dealt to Double Down and Split hands 
	- No Insurance will be offered

Design Choices:
Game Manager
player
dealer

play hand() function

python 


